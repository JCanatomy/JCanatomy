package InventoryAndSchedulingSystem;

public class AddSchedule extends javax.swing.JFrame {

    public AddSchedule() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton3 = new javax.swing.JButton();
        whole_Panel = new javax.swing.JPanel();
        addSchedule_Label = new javax.swing.JLabel();
        back_Button = new javax.swing.JButton();
        lower_Panel = new javax.swing.JPanel();
        personalInfo_Label = new javax.swing.JLabel();
        ownerName_Label = new javax.swing.JLabel();
        ownerName_TextField = new javax.swing.JTextField();
        petName_Label = new javax.swing.JLabel();
        petName_TextField = new javax.swing.JTextField();
        phoneNumber_Label = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        date_Label = new javax.swing.JLabel();
        date_Picker = new com.github.lgooddatepicker.components.DatePicker();
        time_Label = new javax.swing.JLabel();
        time_ComboBox = new javax.swing.JComboBox<>();
        petSize_Label = new javax.swing.JLabel();
        petSize_ComboBox = new javax.swing.JComboBox<>();
        serviceType_Label = new javax.swing.JLabel();
        serviceType_ComboBox = new javax.swing.JComboBox<>();
        price_Label = new javax.swing.JLabel();
        price_TextField = new javax.swing.JTextField();
        add_Button = new javax.swing.JButton();

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setText("Back");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADD SCHEDULE");

        whole_Panel.setBackground(new java.awt.Color(0, 0, 0));

        addSchedule_Label.setText("ADD SCHEDULE");
        addSchedule_Label.setBackground(new java.awt.Color(0, 0, 0));
        addSchedule_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        addSchedule_Label.setForeground(new java.awt.Color(255, 255, 255));

        back_Button.setText("Back");
        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        lower_Panel.setBackground(new java.awt.Color(255, 255, 255));
        lower_Panel.setForeground(new java.awt.Color(255, 255, 255));

        personalInfo_Label.setText("PERSONAL INFORMATION");
        personalInfo_Label.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        ownerName_Label.setText("Owner's Name");
        ownerName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        ownerName_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ownerName_TextFieldActionPerformed(evt);
            }
        });

        petName_Label.setText("Pet's Name");
        petName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        petName_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                petName_TextFieldActionPerformed(evt);
            }
        });

        phoneNumber_Label.setText("Contact No.");
        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        phoneNumber_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneNumber_TextFieldActionPerformed(evt);
            }
        });

        date_Label.setText("Date");
        date_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        time_Label.setText("Time:");
        time_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        time_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        petSize_Label.setText("Pet's Size");
        petSize_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        petSize_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Small Breed", "Medium Breed", "Large Breed" }));
        petSize_ComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                petSize_ComboBoxActionPerformed(evt);
            }
        });

        serviceType_Label.setText("Service Type");
        serviceType_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        serviceType_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        price_Label.setText("Price");
        price_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        price_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                price_TextFieldActionPerformed(evt);
            }
        });

        add_Button.setText("Add");
        add_Button.setBackground(new java.awt.Color(204, 204, 204));
        add_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        add_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        add_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout lower_PanelLayout = new javax.swing.GroupLayout(lower_Panel);
        lower_Panel.setLayout(lower_PanelLayout);
        lower_PanelLayout.setHorizontalGroup(
            lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lower_PanelLayout.createSequentialGroup()
                .addGroup(lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(lower_PanelLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addGroup(lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(time_Label)
                            .addComponent(date_Label)
                            .addComponent(date_Picker, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(price_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(price_Label)
                            .addComponent(serviceType_ComboBox, 0, 200, Short.MAX_VALUE)
                            .addComponent(serviceType_Label)
                            .addComponent(petSize_ComboBox, 0, 200, Short.MAX_VALUE)
                            .addComponent(petSize_Label)
                            .addComponent(ownerName_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(ownerName_Label)
                            .addComponent(petName_Label)
                            .addComponent(petName_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(phoneNumber_Label)
                            .addComponent(phoneNumber_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(time_ComboBox, 0, 200, Short.MAX_VALUE)))
                    .addGroup(lower_PanelLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(personalInfo_Label))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lower_PanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(add_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(78, Short.MAX_VALUE))
        );
        lower_PanelLayout.setVerticalGroup(
            lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lower_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(personalInfo_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ownerName_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ownerName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(petName_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(petName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(phoneNumber_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(phoneNumber_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(date_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(date_Picker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addComponent(time_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(time_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(petSize_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(petSize_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(serviceType_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(serviceType_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(price_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(price_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(add_Button, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lower_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addComponent(addSchedule_Label))
                .addContainerGap(84, Short.MAX_VALUE))
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, whole_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(back_Button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(addSchedule_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lower_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        Menu menuModule = new Menu();
        
        menuModule.menu_TabbedPane.setSelectedIndex(2);
        menuModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void ownerName_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ownerName_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ownerName_TextFieldActionPerformed

    private void price_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_price_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_price_TextFieldActionPerformed

    private void petName_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_petName_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_petName_TextFieldActionPerformed

    private void phoneNumber_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneNumber_TextFieldActionPerformed

    private void add_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_ButtonActionPerformed
        ViewSchedule viewScheduleModule = new ViewSchedule(); 
        viewScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_add_ButtonActionPerformed

    private void petSize_ComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_petSize_ComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_petSize_ComboBoxActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddSchedule().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel addSchedule_Label;
    private javax.swing.JButton add_Button;
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel date_Label;
    private com.github.lgooddatepicker.components.DatePicker date_Picker;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel lower_Panel;
    private javax.swing.JLabel ownerName_Label;
    private javax.swing.JTextField ownerName_TextField;
    private javax.swing.JLabel personalInfo_Label;
    private javax.swing.JLabel petName_Label;
    private javax.swing.JTextField petName_TextField;
    private javax.swing.JComboBox<String> petSize_ComboBox;
    private javax.swing.JLabel petSize_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel price_Label;
    private javax.swing.JTextField price_TextField;
    private javax.swing.JComboBox<String> serviceType_ComboBox;
    private javax.swing.JLabel serviceType_Label;
    private javax.swing.JComboBox<String> time_ComboBox;
    private javax.swing.JLabel time_Label;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
