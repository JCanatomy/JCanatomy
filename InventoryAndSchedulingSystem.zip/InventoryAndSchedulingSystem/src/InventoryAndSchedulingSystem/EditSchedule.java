package InventoryAndSchedulingSystem;
import java.sql.ResultSetMetaData;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.util.Date;
import java.util.Vector;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class EditSchedule extends javax.swing.JFrame {

    static void tableUpdate(String reservation, String newPetName, String newNameOwner, String newContactNumber, String newPetSize, String newServiceType, String newTime, String newPrice) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private final String dbUrl = "jdbc:mysql://localhost:3306/userregistration";
    private final String dbUsername = "root";
    private final String dbPassword = "";

    private Connection con;
    private PreparedStatement insert;

    public EditSchedule() {
        initComponents();
        loadUserData();
        addTableListener();
    }
    
        private void addTableListener() {
        tableUpdate.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting() && tableUpdate.getSelectedRow() != -1) {
                    DefaultTableModel dtm = (DefaultTableModel) tableUpdate.getModel();
                    int selectedIndex = tableUpdate.getSelectedRow();

                    reservatioNo_TextField.setText(dtm.getValueAt(selectedIndex, 0).toString());
                    petName_TextField.setText(dtm.getValueAt(selectedIndex, 1).toString());
                    ownerName_TextField.setText(dtm.getValueAt(selectedIndex, 2).toString());
                    phoneNumber_TextField.setText(dtm.getValueAt(selectedIndex, 3).toString());
                    petSize_ComboBox.setSelectedItem(dtm.getValueAt(selectedIndex, 4).toString());
                    serviceType_ComboBox.setSelectedItem(dtm.getValueAt(selectedIndex, 5).toString());
                    
                    // Handling date conversion and setting date_Picker
                    java.sql.Date date = (java.sql.Date) dtm.getValueAt(selectedIndex, 6); // Assuming Date is in column 6
                    date_Picker.setDate(date.toLocalDate());

                    time_ComboBox.setSelectedItem(dtm.getValueAt(selectedIndex, 7).toString());
                    price_TextField.setText(dtm.getValueAt(selectedIndex, 8).toString());
                }
            }
        });
    }

    private void loadUserData() {
        try {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            insert = con.prepareStatement("Select * from userinfo");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            int c = Rss.getColumnCount();

            DefaultTableModel dtm = (DefaultTableModel) tableUpdate.getModel();
            dtm.setRowCount(0);

            while (rs.next()) {
                Vector vec = new Vector();
                for (int a = 1; a <= c; a++) {
                    vec.add(rs.getString(a));
                }
                dtm.addRow(vec);
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(EditSchedule.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (insert != null) {
                    insert.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(EditSchedule.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        clientShop_Logo = new javax.swing.JLabel();
        editSchedule_Label = new javax.swing.JLabel();
        reservationNo_Label = new javax.swing.JLabel();
        reservatioNo_TextField = new javax.swing.JTextField();
        petName_Label = new javax.swing.JLabel();
        petName_TextField = new javax.swing.JTextField();
        ownerName_Label = new javax.swing.JLabel();
        ownerName_TextField = new javax.swing.JTextField();
        phoneNumber_Label = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        petSize_Label = new javax.swing.JLabel();
        petSize_ComboBox = new javax.swing.JComboBox<>();
        serviceType_Label = new javax.swing.JLabel();
        serviceType_ComboBox = new javax.swing.JComboBox<>();
        date_Label = new javax.swing.JLabel();
        date_Picker = new com.github.lgooddatepicker.components.DatePicker();
        time_Label = new javax.swing.JLabel();
        time_ComboBox = new javax.swing.JComboBox<>();
        price_Label = new javax.swing.JLabel();
        price_TextField = new javax.swing.JTextField();
        editSchedule_ScrollPane = new javax.swing.JScrollPane();
        tableUpdate = new javax.swing.JTable();
        finish_Icon = new javax.swing.JLabel();
        edit_Button = new javax.swing.JButton();
        delete_Button = new javax.swing.JButton();
        logout_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("EDIT SCHEDULE");

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        editSchedule_Label.setText("Edit Schedule");
        editSchedule_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        editSchedule_Label.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addComponent(editSchedule_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(clientShop_Logo))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(back_Button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(editSchedule_Label)
                .addContainerGap())
            .addComponent(clientShop_Logo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        reservationNo_Label.setText("Reservation No.");
        reservationNo_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        petName_Label.setText("Pet's Name");
        petName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        ownerName_Label.setText("Owner's Name");
        ownerName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        phoneNumber_Label.setText("Contact Number");
        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        petSize_Label.setText("Pet's Size ");
        petSize_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        petSize_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        serviceType_Label.setText("Service Type");
        serviceType_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        serviceType_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        date_Label.setText("Date");
        date_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        time_Label.setText("Time");
        time_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        time_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        price_Label.setText("Price");
        price_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        tableUpdate.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Reservation No.", "Owner's Name", "Pet's Name", "Contact No.", "Pet's Size", "Service Type", "Date", "Time", "Price"
            }
        ));
        editSchedule_ScrollPane.setViewportView(tableUpdate);

        finish_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_check.png"))); // NOI18N

        edit_Button.setText("Edit");
        edit_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_ButtonActionPerformed(evt);
            }
        });

        delete_Button.setText("Delete");
        delete_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_ButtonActionPerformed(evt);
            }
        });

        logout_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_exit.png"))); // NOI18N
        logout_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logout_IconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, whole_PanelLayout.createSequentialGroup()
                            .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(petName_Label)
                                .addComponent(ownerName_Label)
                                .addComponent(phoneNumber_Label)
                                .addComponent(petSize_Label)
                                .addComponent(serviceType_Label)
                                .addComponent(date_Label))
                            .addGap(76, 76, 76))
                        .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(price_Label, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(time_ComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, 180, Short.MAX_VALUE)
                            .addComponent(serviceType_ComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(petSize_ComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(phoneNumber_TextField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ownerName_TextField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(petName_TextField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(reservatioNo_TextField, javax.swing.GroupLayout.Alignment.LEADING)))
                    .addComponent(date_Picker, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(time_Label)
                    .addComponent(price_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reservationNo_Label))
                .addGap(2, 2, 2)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(editSchedule_ScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 814, Short.MAX_VALUE)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(finish_Icon)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(edit_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(delete_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(logout_Icon)))
                .addContainerGap())
            .addComponent(top_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(top_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addComponent(editSchedule_ScrollPane)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(finish_Icon)
                            .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(edit_Button)
                                .addComponent(delete_Button)
                                .addComponent(logout_Icon)))
                        .addContainerGap())
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addComponent(reservationNo_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(reservatioNo_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(petName_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(petName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ownerName_Label)
                        .addGap(3, 3, 3)
                        .addComponent(ownerName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(phoneNumber_Label)
                        .addGap(2, 2, 2)
                        .addComponent(phoneNumber_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(petSize_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(petSize_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(serviceType_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(serviceType_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(date_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(date_Picker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3)
                        .addComponent(time_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(time_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(price_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(price_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 34, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        Menu menuModule = new Menu();
        
        menuModule.menu_TabbedPane.setSelectedIndex(2);
        menuModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void logout_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logout_IconMouseClicked
        Login loginModule = new Login();
        loginModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_logout_IconMouseClicked

    private void edit_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_ButtonActionPerformed
DefaultTableModel dtm = (DefaultTableModel) tableUpdate.getModel();
int selectedIndex = tableUpdate.getSelectedRow();

if (selectedIndex == -1) {
    JOptionPane.showMessageDialog(this, "Please select a row to edit.", "No Row Selected", JOptionPane.WARNING_MESSAGE);
    return;
}

try {
    String reservation = dtm.getValueAt(selectedIndex, 0).toString(); 
    String petName = dtm.getValueAt(selectedIndex, 1).toString(); 
    String ownerName = dtm.getValueAt(selectedIndex, 2).toString(); 
    String contactNumber = dtm.getValueAt(selectedIndex, 3).toString(); 
    String petSize = dtm.getValueAt(selectedIndex, 4).toString(); 
    String serviceType = dtm.getValueAt(selectedIndex, 5).toString(); 
    String time = dtm.getValueAt(selectedIndex, 6).toString(); 
    String price = dtm.getValueAt(selectedIndex, 7).toString();

    if (reservation.isEmpty() || petName.isEmpty() || ownerName.isEmpty() || contactNumber.isEmpty() || petSize.isEmpty() || serviceType.isEmpty() || time.isEmpty() || price.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please ensure all fields are filled.", "Incomplete Data", JOptionPane.WARNING_MESSAGE);
        return;
    }
    UpdateSchedule updateSchedule = new UpdateSchedule(reservation, petName, ownerName, contactNumber, petSize, serviceType, time, price);
    updateSchedule.setVisible(true);
    dispose(); 

} catch (Exception ex) {
    JOptionPane.showMessageDialog(this, "Error retrieving data for editing: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}
    }//GEN-LAST:event_edit_ButtonActionPerformed

    private void delete_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_ButtonActionPerformed
    DefaultTableModel dtm = (DefaultTableModel) tableUpdate.getModel();
    int selectedIndex = tableUpdate.getSelectedRow();

    if (selectedIndex == -1) {
        JOptionPane.showMessageDialog(this, "Please select a row to delete.", "No Row Selected", JOptionPane.WARNING_MESSAGE);
        return;
    }

    try {
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "Delete Confirmation", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            // Get data from selected row
            String ownerName = (String) dtm.getValueAt(selectedIndex, 1); // Assuming Owner's Name is in the second column (index 1)

            // Delete record from database
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            insert = con.prepareStatement("DELETE FROM userinfo WHERE OwnerName = ?");
            insert.setString(1, ownerName);
            insert.executeUpdate();

            JOptionPane.showMessageDialog(this, "Record Deleted", "Delete", JOptionPane.INFORMATION_MESSAGE);
            
            // Reload table data or update UI accordingly
            loadUserData(); // Assuming this method reloads the data in your table


            reservatioNo_TextField.setText("");
            petName_TextField.setText("");
            ownerName_TextField.setText("");
            phoneNumber_TextField.setText("");
            price_TextField.setText("");
        }
    } catch (ClassNotFoundException | SQLException ex) {
        Logger.getLogger(EditSchedule.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, "Failed to delete profile.", "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (insert != null) {
                insert.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(EditSchedule.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    }//GEN-LAST:event_delete_ButtonActionPerformed

 
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditSchedule().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel date_Label;
    private com.github.lgooddatepicker.components.DatePicker date_Picker;
    private javax.swing.JButton delete_Button;
    private javax.swing.JLabel editSchedule_Label;
    private javax.swing.JScrollPane editSchedule_ScrollPane;
    private javax.swing.JButton edit_Button;
    private javax.swing.JLabel finish_Icon;
    private javax.swing.JLabel logout_Icon;
    private javax.swing.JLabel ownerName_Label;
    private javax.swing.JTextField ownerName_TextField;
    private javax.swing.JLabel petName_Label;
    private javax.swing.JTextField petName_TextField;
    private javax.swing.JComboBox<String> petSize_ComboBox;
    private javax.swing.JLabel petSize_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel price_Label;
    private javax.swing.JTextField price_TextField;
    private javax.swing.JTextField reservatioNo_TextField;
    private javax.swing.JLabel reservationNo_Label;
    private javax.swing.JComboBox<String> serviceType_ComboBox;
    private javax.swing.JLabel serviceType_Label;
    private javax.swing.JTable tableUpdate;
    private javax.swing.JComboBox<String> time_ComboBox;
    private javax.swing.JLabel time_Label;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
