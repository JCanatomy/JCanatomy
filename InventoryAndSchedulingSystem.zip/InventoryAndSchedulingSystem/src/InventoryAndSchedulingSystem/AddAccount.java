package InventoryAndSchedulingSystem;

import static InventoryAndSchedulingSystem.ViewAdminAccount.adminAccount_Table;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AddAccount extends javax.swing.JFrame {

    public AddAccount() 
    {
        initComponents();
        try 
        {
            Connection();
        } catch (SQLException ex) 
        {
            Logger.getLogger(AddAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";   
    
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        addAccount_Label = new javax.swing.JLabel();
        email_Label = new javax.swing.JLabel();
        email_Icon = new javax.swing.JLabel();
        email_TextField = new javax.swing.JTextField();
        username_Label = new javax.swing.JLabel();
        username_Icon = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        key_Icon = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        phoneNumber_Label = new javax.swing.JLabel();
        phone_Icon = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        clientShop_Logo = new javax.swing.JLabel();
        clientShop_Name = new javax.swing.JLabel();
        add_Button = new javax.swing.JButton();
        show_Icon = new javax.swing.JLabel();
        hide_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADD ACCOUNT");

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        addAccount_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        addAccount_Label.setForeground(new java.awt.Color(255, 255, 255));
        addAccount_Label.setText("ADD ACCOUNT");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(addAccount_Label))
                    .addComponent(back_Button))
                .addContainerGap(340, Short.MAX_VALUE))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(back_Button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(addAccount_Label)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 700, 100));

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        email_Label.setText("Email");
        whole_Panel.add(email_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, -1, -1));

        email_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_envelope.png"))); // NOI18N
        whole_Panel.add(email_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, -1, 30));
        whole_Panel.add(email_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, 200, 32));

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        username_Label.setText("Username");
        whole_Panel.add(username_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));

        username_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_username.png"))); // NOI18N
        whole_Panel.add(username_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, -1, 30));
        whole_Panel.add(username_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, 200, 32));

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        password_Label.setText("Password");
        whole_Panel.add(password_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, -1, -1));

        key_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_key.png"))); // NOI18N
        whole_Panel.add(key_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, -1, 30));
        whole_Panel.add(password_Field, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 280, 200, 30));

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        phoneNumber_Label.setText("Phone Number");
        whole_Panel.add(phoneNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, -1, -1));

        phone_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_phone.png"))); // NOI18N
        whole_Panel.add(phone_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, -1, 30));

        phoneNumber_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                phoneNumber_TextFieldKeyTyped(evt);
            }
        });
        whole_Panel.add(phoneNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 350, 200, 32));

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/2x2_client_logo.png"))); // NOI18N
        whole_Panel.add(clientShop_Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 270, -1, -1));

        clientShop_Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        clientShop_Name.setText("DeTails Pet Essentials and Lodging");
        whole_Panel.add(clientShop_Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 420, -1, -1));

        add_Button.setBackground(new java.awt.Color(204, 204, 204));
        add_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        add_Button.setText("Add");
        add_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        add_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(add_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 400, 90, 30));

        show_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyes.png"))); // NOI18N
        show_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                show_IconMousePressed(evt);
            }
        });
        whole_Panel.add(show_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 280, 30, 30));

        hide_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_hideeye.png"))); // NOI18N
        hide_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                hide_IconMousePressed(evt);
            }
        });
        whole_Panel.add(hide_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 280, 30, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
        private void tableUpdate() throws SQLException{
        
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("SELECT * FROM registration_database");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)adminAccount_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ; a <= c; a++)
                {
                    vec.add(rs.getString("Email"));
                    vec.add(rs.getString("Username"));
                    vec.add(rs.getString("Password"));
                    vec.add(rs.getString("PhoneNumber"));
                }
                    dtm.addRow(vec);
            } 
        }
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        ViewAdminAccount viewAdminAccountModule = new ViewAdminAccount();
        viewAdminAccountModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void add_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_ButtonActionPerformed
        String acc_email = email_TextField.getText();
        String acc_username = username_TextField.getText();
        String acc_password = String.valueOf(password_Field.getPassword());
        String acc_phone_number = phoneNumber_TextField.getText(); 
        
        String Email = email_TextField.getText();
        String Username = username_TextField.getText();
        String Password = password_Field.getText();
        String PhoneNumber = phoneNumber_TextField.getText();
        
         Object[] options = {"YES", "CANCEL"};
         
         try 
            { 
                int choice = JOptionPane.showOptionDialog(null,"Are you sure you want to add " + email_TextField.getText() + "?" ,
                    "Add Record ",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE, null, options,options[0]);
               
                if (choice == JOptionPane.CANCEL_OPTION)
                {    
                        JOptionPane.showMessageDialog(null, "Adding Account was Unsucessful","Unsuccessful",JOptionPane.ERROR_MESSAGE); 
                        email_TextField.setText("");
                        username_TextField.setText("");
                        password_Field.setText("");
                        phoneNumber_TextField.setText("");
                        
                        ViewAdminAccount viewAdminAccountModule = new ViewAdminAccount();
                        viewAdminAccountModule.setVisible(true);
                        dispose();
                }
                else if (choice == JOptionPane.YES_OPTION) 
                { 
                    if (email_TextField.getText().equals("")&& username_TextField.getText().equals("")&& password_Field.getText().equals("")&&phoneNumber_TextField.getText().equals(""))
                    {
                      
                        JOptionPane.showMessageDialog(null, "Empty Fields","Unsuccessful",JOptionPane.ERROR_MESSAGE); 
                    }
                    else
                    {
                    String queryRegister = "INSERT INTO registration_database (Email,Username,Password,PhoneNumber) VALUES ('"+Email+"', '"+Username+"', '"+Password+"','"+PhoneNumber+"')";
                    pst = con.prepareStatement(queryRegister);

                    int rowsAffected = pst.executeUpdate();
                    tableUpdate();
                    
                        if (rowsAffected > 0) 
                        {
                            JOptionPane.showMessageDialog(null, "Profile added successfully","Added",JOptionPane.INFORMATION_MESSAGE); 

                            ViewAdminAccount viewAdminAccountModule = new ViewAdminAccount();
                            viewAdminAccountModule.setVisible(true);
                            dispose();
                        } 
                    
                        else 
                        {
                        JOptionPane.showMessageDialog(null, "Failed to Add profile.");
                        email_TextField.setText("");
                        username_TextField.setText("");
                        password_Field.setText("");
                        phoneNumber_TextField.setText("");
                        }
                    }
                }
            }
            catch (SQLException ex) 
            {
                Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, "Error updating profile", ex);
                JOptionPane.showMessageDialog(null, "An error occurred while updating the profile. Please try again later.","Error",JOptionPane.ERROR_MESSAGE);
            }
    }//GEN-LAST:event_add_ButtonActionPerformed

    private void show_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_show_IconMousePressed
        show_Icon.setVisible(false);
        hide_Icon.setVisible(true);

        password_Field.setEchoChar ((char)0);
    }//GEN-LAST:event_show_IconMousePressed

    private void hide_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hide_IconMousePressed
        show_Icon.setVisible(true);
        hide_Icon.setVisible(false);

        password_Field.setEchoChar ('•');
    }//GEN-LAST:event_hide_IconMousePressed

    private void phoneNumber_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            phoneNumber_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "You can only input numbers", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            phoneNumber_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_phoneNumber_TextFieldKeyTyped


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddAccount().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel addAccount_Label;
    private javax.swing.JButton add_Button;
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel clientShop_Name;
    private javax.swing.JLabel email_Icon;
    private javax.swing.JLabel email_Label;
    private javax.swing.JTextField email_TextField;
    private javax.swing.JLabel hide_Icon;
    private javax.swing.JLabel key_Icon;
    private javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel phone_Icon;
    private javax.swing.JLabel show_Icon;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JLabel username_Icon;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
