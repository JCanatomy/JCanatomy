package InventoryAndSchedulingSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class ViewAdminAccount extends javax.swing.JFrame {

    public ViewAdminAccount() 
    {
        initComponents();
        
        try 
        {
            tableUpdate();  
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }      
    }
    
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";    
   
    
    static int selectedRowIndex;
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        whole_Panel = new javax.swing.JPanel();
        adminAccount_ScrollPane = new javax.swing.JScrollPane();
        adminAccount_Table = new javax.swing.JTable();
        email_Label = new javax.swing.JLabel();
        email_TextField = new javax.swing.JTextField();
        username_Label = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        phoneNumber_Label = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        top_Panel = new javax.swing.JPanel();
        clientShop_Logo = new javax.swing.JLabel();
        back_Button = new javax.swing.JButton();
        adminAccount_Label = new javax.swing.JLabel();
        add_Button = new javax.swing.JButton();
        edit_Button = new javax.swing.JButton();
        delete_Button = new javax.swing.JButton();
        view_Button = new javax.swing.JButton();
        logout_Icon = new javax.swing.JLabel();
        show_Icon = new javax.swing.JLabel();
        hide_Icon = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADMIN ACCOUNT");

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        adminAccount_Table.setForeground(new java.awt.Color(255, 255, 255));
        adminAccount_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Email", "Username", "Password", "Phone Number"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        adminAccount_Table.setToolTipText("");
        adminAccount_Table.getTableHeader().setReorderingAllowed(false);
        adminAccount_Table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                adminAccount_TableMouseClicked(evt);
            }
        });
        adminAccount_ScrollPane.setViewportView(adminAccount_Table);
        if (adminAccount_Table.getColumnModel().getColumnCount() > 0) {
            adminAccount_Table.getColumnModel().getColumn(0).setResizable(false);
            adminAccount_Table.getColumnModel().getColumn(1).setResizable(false);
            adminAccount_Table.getColumnModel().getColumn(2).setResizable(false);
            adminAccount_Table.getColumnModel().getColumn(3).setResizable(false);
        }

        whole_Panel.add(adminAccount_ScrollPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 100, 570, 360));

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        email_Label.setText("Email");
        whole_Panel.add(email_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        email_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        email_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(email_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 200, 35));

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username_Label.setText("Username");
        whole_Panel.add(username_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));

        username_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        username_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(username_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 200, 35));

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        password_Label.setText("Password");
        whole_Panel.add(password_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, -1, -1));

        password_Field.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        password_Field.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(password_Field, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 200, 35));

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phoneNumber_Label.setText("Phone Number");
        whole_Panel.add(phoneNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, -1, -1));

        phoneNumber_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        phoneNumber_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(phoneNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, 200, 35));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        adminAccount_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        adminAccount_Label.setForeground(new java.awt.Color(255, 255, 255));
        adminAccount_Label.setText("Admin Account");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(adminAccount_Label)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 488, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addGap(17, 17, 17))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(adminAccount_Label))
                    .addComponent(clientShop_Logo))
                .addContainerGap(7, Short.MAX_VALUE))
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 90));

        add_Button.setBackground(new java.awt.Color(204, 204, 204));
        add_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        add_Button.setText("Add Account ");
        add_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(add_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 470, -1, -1));

        edit_Button.setBackground(new java.awt.Color(204, 204, 204));
        edit_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        edit_Button.setText("Edit Account");
        edit_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(edit_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 470, -1, -1));

        delete_Button.setBackground(new java.awt.Color(204, 204, 204));
        delete_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        delete_Button.setText("Delete Account ");
        delete_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(delete_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 470, -1, -1));

        view_Button.setBackground(new java.awt.Color(204, 204, 204));
        view_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        view_Button.setText("View Account ");
        view_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(view_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 470, -1, -1));

        logout_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_exit.png"))); // NOI18N
        logout_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logout_IconMouseClicked(evt);
            }
        });
        whole_Panel.add(logout_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 470, 40, -1));

        show_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyes.png"))); // NOI18N
        show_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                show_IconMousePressed(evt);
            }
        });
        whole_Panel.add(show_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 270, -1, 30));

        hide_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_hideeye.png"))); // NOI18N
        hide_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                hide_IconMousePressed(evt);
            }
        });
        whole_Panel.add(hide_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 270, -1, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    private void tableUpdate() throws SQLException{
        
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("SELECT * FROM registration_database");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)adminAccount_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ; a <= c; a++)
                {
//                    for (int i = 0; i < adminAccount_Table.getRowCount(); i++)
//                    {
//                        adminAccount_Table.setValueAt( i + 1, i, 0);
//                    }
                    vec.add(rs.getString("Email"));
                    vec.add(rs.getString("Username"));
                    vec.add(rs.getString("Password"));
                    vec.add(rs.getString("PhoneNumber"));
                }
                dtm.addRow(vec);
            } 
        }
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        Menu menuModule = new Menu();
        menuModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void add_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_ButtonActionPerformed
       AddAccount addAccountModule = new AddAccount();
       addAccountModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_add_ButtonActionPerformed

    private void edit_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_ButtonActionPerformed
       EditAccount editAccountModule = new EditAccount();
       editAccountModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_edit_ButtonActionPerformed

    private void view_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view_ButtonActionPerformed
        ViewAccount viewAccountModule = new ViewAccount();
        viewAccountModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_view_ButtonActionPerformed

    private void logout_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logout_IconMouseClicked
       Login loginModule = new Login();
       loginModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_logout_IconMouseClicked

    private void adminAccount_TableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adminAccount_TableMouseClicked
       
       DefaultTableModel dtm = (DefaultTableModel)adminAccount_Table.getModel();
       int selectedIndex = adminAccount_Table.getSelectedRow();

        selectedRowIndex = adminAccount_Table.getSelectedRow();
    
        email_TextField.setText(dtm.getValueAt(selectedIndex, 0).toString());
        username_TextField.setText(dtm.getValueAt(selectedIndex, 1).toString());
        password_Field.setText(dtm.getValueAt(selectedIndex, 2).toString());
        phoneNumber_TextField.setText(dtm.getValueAt(selectedIndex, 3).toString());
        
    }//GEN-LAST:event_adminAccount_TableMouseClicked

    private void hide_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hide_IconMousePressed
        show_Icon.setVisible(true);
        hide_Icon.setVisible(false);
        
        password_Field.setEchoChar ('•');
    }//GEN-LAST:event_hide_IconMousePressed

    private void show_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_show_IconMousePressed
        show_Icon.setVisible(false);
        hide_Icon.setVisible(true);
        
        password_Field.setEchoChar ((char)0); 
    }//GEN-LAST:event_show_IconMousePressed

    private void delete_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_ButtonActionPerformed
        String Email = email_TextField.getText();
        String Username = username_TextField.getText();
        String Password = password_Field.getText();
        String PhoneNumber = phoneNumber_TextField.getText();

        DefaultTableModel dtm = (DefaultTableModel)adminAccount_Table.getModel();
        int selectedIndex = adminAccount_Table.getSelectedRow();
        
        try
        {
            int choice = JOptionPane.showConfirmDialog(this,"Are you sure you want to delete " + username_TextField.getText() + "?" ,"Delete",JOptionPane.YES_NO_OPTION);
            
            if (choice == JOptionPane.YES_OPTION )
            {
            
                Class.forName(dbDriver);
                con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);  
                insert = con.prepareStatement("DELETE FROM registration_database WHERE Email =? ");
                insert.setString(1, Email);
                insert.executeUpdate();

                JOptionPane.showMessageDialog(this, "Record Deleted ","Delete",JOptionPane.INFORMATION_MESSAGE);
                tableUpdate();

                email_TextField.setText("");
                username_TextField.setText("");
                password_Field.setText("");
                phoneNumber_TextField.setText("");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "DEle","Error",JOptionPane.ERROR_MESSAGE);   
                email_TextField.setText("");
                username_TextField.setText("");
                password_Field.setText("");
                phoneNumber_TextField.setText("");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (SQLException ex) 
        {
               Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_delete_ButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewAdminAccount().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add_Button;
    private javax.swing.JLabel adminAccount_Label;
    private javax.swing.JScrollPane adminAccount_ScrollPane;
    public static javax.swing.JTable adminAccount_Table;
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JButton delete_Button;
    private javax.swing.JButton edit_Button;
    private javax.swing.JLabel email_Label;
    public static javax.swing.JTextField email_TextField;
    private javax.swing.JLabel hide_Icon;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel logout_Icon;
    public static javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phoneNumber_Label;
    public static javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel show_Icon;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JLabel username_Label;
    public static javax.swing.JTextField username_TextField;
    private javax.swing.JButton view_Button;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
