package InventoryAndSchedulingSystem;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
    
public class Registration extends javax.swing.JFrame {
  
    public Registration() 
    {
        initComponents(); 
        try 
        {
            Connection();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
           
    }
    
    Connection con;
    Statement st;
     
    private static final String dbName = "registration";
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";
    
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            if (con != null)
            {
                System.out.println("Connection Successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField1 = new javax.swing.JPasswordField();
        left_Panel = new javax.swing.JPanel();
        right_Panel = new javax.swing.JPanel();
        registration_Label = new javax.swing.JLabel();
        greetings_Label = new javax.swing.JLabel();
        email_Label = new javax.swing.JLabel();
        email_Icon = new javax.swing.JLabel();
        email_TextField = new javax.swing.JTextField();
        username_Label = new javax.swing.JLabel();
        username_Icon = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        key_Icon = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        show_Icon = new javax.swing.JLabel();
        hide_Icon = new javax.swing.JLabel();
        confirmPassword_Label = new javax.swing.JLabel();
        check_Icon = new javax.swing.JLabel();
        confirmPassword_Field = new javax.swing.JPasswordField();
        showConfirm_Icon = new javax.swing.JLabel();
        hideConfirm_Icon = new javax.swing.JLabel();
        phoneNumber_Label = new javax.swing.JLabel();
        phone_Icon = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        register_Button = new javax.swing.JButton();
        signIn_Label_Button = new javax.swing.JLabel();
        signIn_Labels_Buttons = new javax.swing.JLabel();
        clientShop_Logo = new javax.swing.JLabel();
        clientShop_Name = new javax.swing.JLabel();

        jPasswordField1.setText("jPasswordField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("REGISTRATION");
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        left_Panel.setBackground(new java.awt.Color(0, 0, 0));
        left_Panel.setPreferredSize(new java.awt.Dimension(800, 600));

        right_Panel.setBackground(new java.awt.Color(255, 255, 255));
        right_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        registration_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        registration_Label.setText("REGISTRATION");
        right_Panel.add(registration_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 18, 360, -1));

        greetings_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        greetings_Label.setText("LET'S GET STARTED ");
        right_Panel.add(greetings_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 88, -1, -1));

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        email_Label.setText("Email");
        right_Panel.add(email_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 116, -1, -1));

        email_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_envelope.png"))); // NOI18N
        right_Panel.add(email_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 144, -1, 36));

        email_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        email_TextField.setForeground(new java.awt.Color(153, 153, 153));
        email_TextField.setText("Enter Email");
        email_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                email_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                email_TextFieldFocusLost(evt);
            }
        });
        right_Panel.add(email_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 144, 260, 36));

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        username_Label.setText("Username");
        right_Panel.add(username_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 186, -1, -1));

        username_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_username.png"))); // NOI18N
        right_Panel.add(username_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 214, -1, 36));

        username_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        username_TextField.setForeground(new java.awt.Color(153, 153, 153));
        username_TextField.setText("Enter Username");
        username_TextField.setToolTipText("");
        username_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                username_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                username_TextFieldFocusLost(evt);
            }
        });
        right_Panel.add(username_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 214, 260, 36));

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        password_Label.setText("Password");
        right_Panel.add(password_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 256, -1, -1));

        key_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_key.png"))); // NOI18N
        right_Panel.add(key_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 284, -1, 36));

        password_Field.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        password_Field.setForeground(new java.awt.Color(153, 153, 153));
        password_Field.setText("Enter Password");
        password_Field.setEchoChar('\u0000');
        password_Field.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                password_FieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                password_FieldFocusLost(evt);
            }
        });
        right_Panel.add(password_Field, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 284, 260, 36));

        show_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyes.png"))); // NOI18N
        show_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                show_IconMousePressed(evt);
            }
        });
        right_Panel.add(show_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 290, -1, -1));

        hide_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_hideeye.png"))); // NOI18N
        hide_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                hide_IconMousePressed(evt);
            }
        });
        right_Panel.add(hide_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 290, -1, -1));

        confirmPassword_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        confirmPassword_Label.setText("Confirm Password");
        right_Panel.add(confirmPassword_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 328, -1, -1));

        check_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_check.png"))); // NOI18N
        right_Panel.add(check_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 356, -1, 36));

        confirmPassword_Field.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        confirmPassword_Field.setForeground(new java.awt.Color(153, 153, 153));
        confirmPassword_Field.setText("Confirm Password");
        confirmPassword_Field.setEchoChar('\u0000');
        confirmPassword_Field.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                confirmPassword_FieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                confirmPassword_FieldFocusLost(evt);
            }
        });
        right_Panel.add(confirmPassword_Field, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 356, 260, 36));

        showConfirm_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyes.png"))); // NOI18N
        showConfirm_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                showConfirm_IconMousePressed(evt);
            }
        });
        right_Panel.add(showConfirm_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 360, -1, -1));

        hideConfirm_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_hideeye.png"))); // NOI18N
        hideConfirm_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                hideConfirm_IconMousePressed(evt);
            }
        });
        right_Panel.add(hideConfirm_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 360, -1, -1));

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        phoneNumber_Label.setText("Phone Number");
        right_Panel.add(phoneNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 398, -1, -1));

        phone_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_phone.png"))); // NOI18N
        right_Panel.add(phone_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 426, -1, 36));

        phoneNumber_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        phoneNumber_TextField.setForeground(new java.awt.Color(153, 153, 153));
        phoneNumber_TextField.setText("Enter Phone Number");
        phoneNumber_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                phoneNumber_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                phoneNumber_TextFieldFocusLost(evt);
            }
        });
        phoneNumber_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                phoneNumber_TextFieldKeyTyped(evt);
            }
        });
        right_Panel.add(phoneNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 426, 260, 36));

        register_Button.setBackground(new java.awt.Color(0, 0, 0));
        register_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        register_Button.setForeground(new java.awt.Color(255, 255, 255));
        register_Button.setText("REGISTER");
        register_Button.setToolTipText("");
        register_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        register_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                register_ButtonActionPerformed(evt);
            }
        });
        right_Panel.add(register_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 480, 322, 40));

        signIn_Label_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        signIn_Label_Button.setText("Already have an account? ");
        signIn_Label_Button.setToolTipText("Click to go to login page");
        signIn_Label_Button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signIn_Label_ButtonMouseClicked(evt);
            }
        });
        right_Panel.add(signIn_Label_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 530, 180, 30));

        signIn_Labels_Buttons.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        signIn_Labels_Buttons.setForeground(new java.awt.Color(102, 0, 0));
        signIn_Labels_Buttons.setText("Sign In");
        signIn_Labels_Buttons.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signIn_Labels_ButtonsMouseClicked(evt);
            }
        });
        right_Panel.add(signIn_Labels_Buttons, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 530, 90, 30));

        clientShop_Logo.setForeground(new java.awt.Color(255, 255, 255));
        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/client_logo.png"))); // NOI18N

        clientShop_Name.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        clientShop_Name.setForeground(new java.awt.Color(255, 255, 255));
        clientShop_Name.setText("DeTails Pet Essentials and Lodging");

        javax.swing.GroupLayout left_PanelLayout = new javax.swing.GroupLayout(left_Panel);
        left_Panel.setLayout(left_PanelLayout);
        left_PanelLayout.setHorizontalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addContainerGap(75, Short.MAX_VALUE)
                .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clientShop_Logo)
                    .addComponent(clientShop_Name, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addComponent(right_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        left_PanelLayout.setVerticalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(clientShop_Logo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(clientShop_Name)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(right_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(left_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(left_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void show_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_show_IconMousePressed
        show_Icon.setVisible(false);
        hide_Icon.setVisible(true);
        
        password_Field.setEchoChar ((char)0);        
    }//GEN-LAST:event_show_IconMousePressed

    private void hide_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hide_IconMousePressed
        show_Icon.setVisible(true);
        hide_Icon.setVisible(false);
        
        password_Field.setEchoChar ('•');
    }//GEN-LAST:event_hide_IconMousePressed

    private void showConfirm_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showConfirm_IconMousePressed
        showConfirm_Icon.setVisible(false);
        hideConfirm_Icon.setVisible(true);
        
        confirmPassword_Field.setEchoChar ((char)0);  
    }//GEN-LAST:event_showConfirm_IconMousePressed

    private void hideConfirm_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hideConfirm_IconMousePressed
        showConfirm_Icon.setVisible(true);
        hideConfirm_Icon.setVisible(false);
        
        confirmPassword_Field.setEchoChar ('•');
    }//GEN-LAST:event_hideConfirm_IconMousePressed

    private void email_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_email_TextFieldFocusGained
       if ( email_TextField.getText().equals("Enter Email"))
        {
             email_TextField.setText("");
             email_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_email_TextFieldFocusGained

    private void email_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_email_TextFieldFocusLost
        if (email_TextField.getText().equals(""))
        {
            email_TextField.setText("Enter Email");
            email_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_email_TextFieldFocusLost

    private void username_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_username_TextFieldFocusGained
        if (username_TextField.getText().equals("Enter Username"))
        {
            username_TextField.setText("");
            username_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_username_TextFieldFocusGained

    private void username_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_username_TextFieldFocusLost
        if (username_TextField.getText().equals(""))
        {
            username_TextField.setText("Enter Username");
            username_TextField.setForeground(new java.awt.Color(153,153,153));
        }     
    }//GEN-LAST:event_username_TextFieldFocusLost

    private void password_FieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_password_FieldFocusGained
        if (String.valueOf(password_Field.getPassword()).equals("Enter Password"))
        {
           password_Field.setText("");
           password_Field.setForeground(Color.BLACK);
           password_Field.setEchoChar('•');
        }
    }//GEN-LAST:event_password_FieldFocusGained

    private void password_FieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_password_FieldFocusLost
       if (password_Field.getPassword().length<1)
        {
            password_Field.setEchoChar('\u0000');
            password_Field.setText("Enter Password");
            password_Field.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_password_FieldFocusLost

    private void confirmPassword_FieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_confirmPassword_FieldFocusGained
        if (String.valueOf(confirmPassword_Field.getPassword()).equals("Confirm Password"))
        {
           confirmPassword_Field.setText("");
           confirmPassword_Field.setForeground(Color.BLACK);
           confirmPassword_Field.setEchoChar('•');
        }
    }//GEN-LAST:event_confirmPassword_FieldFocusGained

    private void confirmPassword_FieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_confirmPassword_FieldFocusLost
        if (confirmPassword_Field.getPassword().length<1)
        {
            confirmPassword_Field.setEchoChar('\u0000');
            confirmPassword_Field.setText("Confirm Password");
            confirmPassword_Field.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_confirmPassword_FieldFocusLost

    private void phoneNumber_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldFocusGained
        if (phoneNumber_TextField.getText().equals("Enter Phone Number"))
        {
            phoneNumber_TextField.setText("");
            phoneNumber_TextField.setForeground(Color.BLACK);
        }       
    }//GEN-LAST:event_phoneNumber_TextFieldFocusGained

    private void phoneNumber_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldFocusLost
        if (phoneNumber_TextField.getText().equals(""))
        {
            phoneNumber_TextField.setText("Enter Phone Number");
            phoneNumber_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_phoneNumber_TextFieldFocusLost

    private void signIn_Label_ButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signIn_Label_ButtonMouseClicked
        Login loginModule = new Login();
        loginModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_signIn_Label_ButtonMouseClicked

    private void signIn_Labels_ButtonsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signIn_Labels_ButtonsMouseClicked
        Login loginModule = new Login();
        loginModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_signIn_Labels_ButtonsMouseClicked
   
    private void register_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_register_ButtonActionPerformed
        String acc_email = email_TextField.getText();
        String acc_username = username_TextField.getText();
        String acc_password = String.valueOf(password_Field.getPassword());
        String acc_confirm_password = String.valueOf(confirmPassword_Field.getPassword());
        String acc_phone_number = phoneNumber_TextField.getText();  

        //Blank Input
        if (email_TextField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Email is required","ERROR",JOptionPane.ERROR_MESSAGE);
        }
        else if (username_TextField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Username is required","ERROR",JOptionPane.ERROR_MESSAGE);
        }  
        else if (password_Field.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Password is required","ERROR",JOptionPane.ERROR_MESSAGE);
        } 
        else if (confirmPassword_Field.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Confirm Password field is required","ERROR",JOptionPane.ERROR_MESSAGE);
        }
        else if (phoneNumber_TextField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Phone Number is required","ERROR",JOptionPane.ERROR_MESSAGE);
        }
        //Invalid Input
        else if (email_TextField.getText().equals("Enter Email"))
        {
            JOptionPane.showMessageDialog(null, "Invalid Input","ERROR",JOptionPane.ERROR_MESSAGE);
        }
        else if (username_TextField.getText().equals("Enter Username"))
        {
            JOptionPane.showMessageDialog(null, "Invalid Input","ERROR",JOptionPane.ERROR_MESSAGE);
        }  
        else if (password_Field.getText().equals("Enter Password"))
        {
            JOptionPane.showMessageDialog(null, "Invalid Input","ERROR",JOptionPane.ERROR_MESSAGE);
        } 
        else if (confirmPassword_Field.getText().equals("Confirm Password"))
        {
            JOptionPane.showMessageDialog(null, "Invalid Input","ERROR",JOptionPane.ERROR_MESSAGE);
        }
        else if (phoneNumber_TextField.getText().equals("Enter Phone Number"))
        {
            JOptionPane.showMessageDialog(null, "Invalid Input","ERROR",JOptionPane.ERROR_MESSAGE);
        }
        //all
        else if (email_TextField.getText().equals("") && username_TextField.getText().equals("") && 
                 password_Field.getText().equals("") && confirmPassword_Field.getText().equals("") && 
                 phoneNumber_TextField.getText().equals("")) 
        {
            JOptionPane.showMessageDialog(null, "Please Input in the field","ERROR",JOptionPane.ERROR_MESSAGE);
        }
        
        else if (email_TextField.getText().equals("Enter Email") && username_TextField.getText().equals("Enter Username") && 
                 password_Field.getText().equals("Enter Password") && confirmPassword_Field.getText().equals("Confirm Password") && 
                 phoneNumber_TextField.getText().equals("Enter Phone Number")) 
        {
            JOptionPane.showMessageDialog(null, "Please Input in the field","ERROR",JOptionPane.ERROR_MESSAGE);
        }
        else 
        {
            String queryRegister = "INSERT INTO registration_database (Email,Username,Password,PhoneNumber) VALUES ('"+acc_email+"', '"+acc_username+"', '"+acc_password+"','"+acc_phone_number+"')";
  
            try 
            {
               st.execute(queryRegister );
                JOptionPane.showMessageDialog(new JFrame(), "Register Successfully.",
                                            "Registration Success",JOptionPane.INFORMATION_MESSAGE);
               email_TextField.setText("");
               username_TextField.setText("");
               password_Field.setText("");
               confirmPassword_Field.setText("");
               phoneNumber_TextField.setText("");
               
               Login loginFrame = new Login();
               loginFrame.setVisible(true);
               dispose();
               
            }
            catch (SQLException ex) 
            {
               Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            }           
        }    
    }//GEN-LAST:event_register_ButtonActionPerformed

    private void phoneNumber_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            phoneNumber_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "You can only input numbers", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            phoneNumber_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_phoneNumber_TextFieldKeyTyped

    
  
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registration().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel check_Icon;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel clientShop_Name;
    private javax.swing.JPasswordField confirmPassword_Field;
    private javax.swing.JLabel confirmPassword_Label;
    private javax.swing.JLabel email_Icon;
    private javax.swing.JLabel email_Label;
    private javax.swing.JTextField email_TextField;
    private javax.swing.JLabel greetings_Label;
    private javax.swing.JLabel hideConfirm_Icon;
    private javax.swing.JLabel hide_Icon;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JLabel key_Icon;
    private javax.swing.JPanel left_Panel;
    private javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel phone_Icon;
    private javax.swing.JButton register_Button;
    private javax.swing.JLabel registration_Label;
    private javax.swing.JPanel right_Panel;
    private javax.swing.JLabel showConfirm_Icon;
    private javax.swing.JLabel show_Icon;
    private javax.swing.JLabel signIn_Label_Button;
    private javax.swing.JLabel signIn_Labels_Buttons;
    private javax.swing.JLabel username_Icon;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    // End of variables declaration//GEN-END:variables
}
