package InventoryAndSchedulingSystem;

public class ViewProduct extends javax.swing.JFrame {

    public ViewProduct() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        whole_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        viewProduct_Label = new javax.swing.JLabel();
        lower_Panel = new javax.swing.JPanel();
        viewProduct_ScrollPane = new javax.swing.JScrollPane();
        viewProduct_Table = new javax.swing.JTable();
        logout_Icon = new javax.swing.JLabel();
        clientShop_Logo = new javax.swing.JLabel();

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Product Number");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("VIEW PRODUCT");

        whole_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        viewProduct_Label.setBackground(new java.awt.Color(0, 0, 0));
        viewProduct_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        viewProduct_Label.setForeground(new java.awt.Color(255, 255, 255));
        viewProduct_Label.setText("VIEW PRODUCT");

        lower_Panel.setBackground(new java.awt.Color(255, 255, 255));
        lower_Panel.setForeground(new java.awt.Color(255, 255, 255));

        viewProduct_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Product No.", "Product Name", "Price", "Quantity", "Category"
            }
        ));
        viewProduct_ScrollPane.setViewportView(viewProduct_Table);
        if (viewProduct_Table.getColumnModel().getColumnCount() > 0) {
            viewProduct_Table.getColumnModel().getColumn(1).setResizable(false);
            viewProduct_Table.getColumnModel().getColumn(2).setResizable(false);
        }

        logout_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_exit.png"))); // NOI18N
        logout_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logout_IconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout lower_PanelLayout = new javax.swing.GroupLayout(lower_Panel);
        lower_Panel.setLayout(lower_PanelLayout);
        lower_PanelLayout.setHorizontalGroup(
            lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lower_PanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(logout_Icon)
                    .addComponent(viewProduct_ScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 750, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        lower_PanelLayout.setVerticalGroup(
            lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lower_PanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(viewProduct_ScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(logout_Icon)
                .addGap(7, 7, 7))
        );

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, whole_PanelLayout.createSequentialGroup()
                .addComponent(lower_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addComponent(viewProduct_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addGap(15, 15, 15))
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(viewProduct_Label))
                    .addComponent(clientShop_Logo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addComponent(lower_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        Menu menuModule = new Menu();
        
        menuModule.menu_TabbedPane.setSelectedIndex(1);
        menuModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void logout_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logout_IconMouseClicked
        Login loginModule = new Login();
        loginModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_logout_IconMouseClicked

   
    public static void main(String args[]) {
     

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewProduct().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel logout_Icon;
    private javax.swing.JPanel lower_Panel;
    private javax.swing.JLabel viewProduct_Label;
    private javax.swing.JScrollPane viewProduct_ScrollPane;
    private javax.swing.JTable viewProduct_Table;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
